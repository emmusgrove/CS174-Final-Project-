#ifndef SHAPES_H
#define SHAPES_H

#include "simplecanvas/simplecanvas.h"
#include <iostream>
#include <string>
using namespace std;

class Shape {
    protected:
        float thickness;
        int color[3];
    public:
        Shape(float thickness, int color[3]);
        Shape(){};
        void draw(SimpleCanvas* canvas);
};

class Point: public Shape {
    private:
        float ax;
        float ay;
    public:
        Point(float thickness, int color[3], float ax, float ay);
        Point(){};
        float getX();
        float getY();
        void draw(SimpleCanvas* canvas);
        string toString();
};



class LineSegment: public Shape {
    private:
        Point a;
        Point b;
    public:
        LineSegment(float thickness, int color[3], Point a, Point b);
        LineSegment(){};
        float getLength();
        Point getA();
        Point getB();
        void draw(SimpleCanvas* canvas);
};

class Triangle: public Shape {
    private:
        LineSegment la;
        LineSegment lb;
        LineSegment lc;
        Point a;
        Point b;
        Point c;
    public:
        Triangle(float thickness, int color[3], Point a, Point b, Point c);
        Triangle(){};
        LineSegment getLa();
        LineSegment getLb();
        LineSegment getLc();
        void draw(SimpleCanvas* canvas);
};


class Square: public Shape {
    private:
    LineSegment la;
    LineSegment lb;
    LineSegment lc;
    LineSegment ld;

    public:
    /**
     * @brief Square constructor that accepts a center point object and a line length
     * 
     * @param thickness Thickness of pen drawing
     * @param color Color to draw
     * @param center Point object that represents the center of the shape
     * @param lineLength The line length of each of the 4 equal length sides
     */
    Square(float thickness, int color[3], Point a, Point b, Point c, Point d);

    // Dummy constructor for empty object declarations
    Square(){};

    /**
     * Draw the square on a particular canvas
     * 
     * @param canvas Pointer to canvas 
     */
    void draw(SimpleCanvas* canvas);

};

class Circle: public Shape {
    private:
    float numOfLines;
    Point center;
    float radius;

    public:
    /**
     * Circle constructor that accepts the intended center point of the circle, the number of lines, and 
     * the radius of the circle.
     * 
     * @param thickness Thickness of pen drawing
     * @param color Color to draw
     * @param center Point object that represents the center of the shape
     * @param numOfLines The number of line segments that the circle is made up of
     * @param radius The radius of the circle shape
     */
    Circle(float thickness, int color[3], Point center, float numOfLines, float radius);

    // Dummy constructor for empty object declarations
    Circle(){};

    /**
     * Get the area of this circle
     * 
     * @return float; The area of the square determined by the formula pi*r^2
     */
    float getArea();

    /**
     * Draw the circle on a particular canvas
     * 
     * @param canvas Pointer to canvas
     */
    void draw(SimpleCanvas* canvas);

    /**
     * Get a string that describes the circle
     * 
     * @return string; Returns a string that states the X and Y value of the center point, 
     * the number of lines that makes up the pseudo-circle, and the radius of the circle
     */
    string toString();
};

#endif