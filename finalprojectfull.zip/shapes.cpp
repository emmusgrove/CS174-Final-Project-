#include "simplecanvas/simplecanvas.h"
#include <string>
#include <sstream>
#include <math.h>
#include "shapes.h"
using namespace std;

Shape::Shape(float thickness, int color[3]) {
    this->thickness = thickness;
    for (int k = 0; k < 3; k++) {
        this->color[k] = color[k];
    }
}

void Shape::draw(SimpleCanvas* canvas) {
    cout << "Warning: Calling draw on base class";
}

/////////////////////////////////////////////////////

Point::Point(float thickness, int color[3], float ax, float ay):Shape(thickness, color) {
    this->ax = ax;
    this->ay = ay;
}

float Point::getX() {
    return ax;
}

float Point::getY() {
    return ay;
}

void Point::draw(SimpleCanvas* canvas) {
    canvas->fillCircle((int)ax, (int)ay, thickness, color[0], color[1], color[2]);
}

string Point::toString() {
    stringstream stream;
    stream << "Point(" << ax << ", " << ay << ")";
    return stream.str();
}

/////////////////////////////////////////////////////

LineSegment::LineSegment(float thickness, int color[3], 
                        Point a, Point b):Shape(thickness, color) {
    this->a = a;
    this->b = b;
}

Point LineSegment::getA() {
    return a; 
}

Point LineSegment::getB() {
    return b; 
}

float LineSegment::getLength() {
    float diffx = a.getX() - b.getX();
    float diffy = a.getY() - b.getY();
    return sqrt(diffx*diffx + diffy*diffy);
}

void LineSegment::draw(SimpleCanvas* canvas) {
    canvas->drawLine(a.getX(), a.getY(), b.getX(), b.getY(), thickness, color[0], color[1], color[2]);
}

/////////////////////////////////////////////////////

Triangle::Triangle(float thickness, int color[3], Point a, Point b, Point c):Shape(thickness, color)
{
    this->a = a;
    this->b = b;
    this->c = c;
    LineSegment la(thickness, color, a, b);
    LineSegment lb(thickness, color, a, c);
    LineSegment lc(thickness, color, b, c);
    this->la = la;
    this->lb = lb;
    this->lc = lc;
    
}

LineSegment Triangle::getLa() {
    return la;
}

LineSegment Triangle::getLb() {
    return lb;
}

LineSegment Triangle::getLc() {
    return lc;
}

void Triangle::draw(SimpleCanvas* canvas) {
    la.draw(canvas);
    lb.draw(canvas);
    lc.draw(canvas);
}

/////////////////////////////////////////////////////


/**
 * A constructor for the Square shape that accepts a center point and line length.
 * 
 * @param thickness Thickness of pen drawing
 * @param color Color to draw
 * @param center The Point object that represents the center of the square
 * @param lineLength The length of all 4 lines (which all have the same length)
 */
Square::Square(float thickness, int color[3], Point a, Point b, Point c, Point d):Shape(thickness, color)
{
    LineSegment la(thickness, color, a, b);
    LineSegment lb(thickness, color, b, c);
    LineSegment lc(thickness, color, c, d);
    LineSegment ld(thickness, color, d, a);
    this->la = la;
    this->lb = lb;
    this->lc = lc;
    this->ld = ld;

} 

/**
 * This draws a four sided shape in which all the sides are connected for the square. This is draw on the provided canvas. 
 * 
 * @param canvas The pointer to the canvas that the square is drawn on. 
 */
void Square::draw(SimpleCanvas* canvas) {
    la.draw(canvas);
    lb.draw(canvas);
    lc.draw(canvas);
    ld.draw(canvas);
}


/////////////////////////////////////////////////////


/**
 * A constructor for the Circle shape which is a pseudo circle which consists of multiple line segments in the shape of a circle. 
 * 
 * @param thickness Thickness of pen drawing
 * @param color Color to draw
 * @param center Point object that represents the center of the shape
 * @param numOfLines The number of line segments that the circle is made up of
 * @param radius The radius of the circle shape
 */
Circle::Circle(float thickness, int color[3], Point center, float numOfLines, float radius):Shape(thickness, color)
{
    this->center=center;
    this->numOfLines=numOfLines;
    this->radius=radius;
}

/**
 * This returns the area of the circle shape 
 * 
 * @return float; The returns the area of the circle determined by the formula pi*r^2
 */
float Circle::getArea() {
    return M_PI*pow(radius, 2);
}

/**
 * This draws the circle shape by drawing a line connecting 2 points, X value of which is determined by the formula cx+r*cos((2*pi*i)/N)
 * and the Y value of which is determined by the formula cy+r*sin((2*pi*i)/N). This draws certain amount of lines to form the shape of a
 * circle. 
 * 
 * @param canvas A pointer the canvas to draw on
 */
void Circle::draw(SimpleCanvas* canvas)
{
    for(int i = 1; i < numOfLines+1; i++)
    {
        int xone = center.getX()+radius*cos((2*M_PI*i)/numOfLines);
        int yone = center.getY()+radius*sin((2*M_PI*i)/numOfLines);
        int xtwo = center.getX()+radius*cos((2*M_PI*(i+1))/numOfLines);
        int ytwo = center.getY()+radius*sin((2*M_PI*(i+1))/numOfLines);
        canvas->drawLine(xone, yone, xtwo, ytwo, thickness, color[0], color[1], color[2]);
    }
}

/**
 * Returns the value of the radius, the number of lines, and the center point values of a given circle. 
 * 
 * @return string; This returns the radius, number of lines, and center point of the circle. 
 */
string Circle::toString() {
    stringstream stream;
    stream << "Circle with a radius of " << radius << ", " << numOfLines << " lines, and a center at " << center.toString();
    return stream.str();
}