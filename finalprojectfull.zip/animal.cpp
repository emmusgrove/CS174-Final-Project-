#include "simulation.h"
#include "animal.h"
#include "randutils.h"
#include <stdio.h>
#include <math.h>
#include <iostream>
using namespace std;

Animal::Animal(Simulation* sim, float vx, float vy){
    this->simulation = sim;
    RandFloat * r = new RandFloat();
    x = r->nextFloat();
    y = r->nextFloat();
    float speed = sqrt(pow(vx, 2)+pow(vy, 2));
    this->speed = speed;
    this->vx = vx;
    this->vy = vy;
    delete r;
}

Animal::Animal(Simulation* sim, float x, float y, float vx, float vy){
    this->simulation = sim;
    RandFloat * r = new RandFloat();
    this->x = x;
    this->y = y; 
    float speed = sqrt(pow(vx, 2)+pow(vy, 2));
    this->speed = speed;
    this->vx = vx;
    this->vy = vy;
    r = 0; 
    b = 0;
    g = 0;
    delete r;
}

void Animal::draw()
{
    simulation->circle(x, y, r, g, b, 0.005);
}

void Animal::action(float dt)
{

    Animal* u = simulation->findFriends(this);
    if(u != NULL)
    {
       /*double k = sqrt(pow((x-u->getX()), 2) + pow((y-u->getY()), 2)); 
       vx = 0.1*(u->getX()-x)/k;
       vy = 0.1*(u->getY()-y)/k;*/
       float dist = sqrt(pow((x-u->getX()), 2) + pow((y-u->getY()), 2));
       vx = speed*(u->getX()-x)/dist;
       vy = speed*(u->getY()-y)/dist;
    }
    //cout << "The x is " << x << " the velocity in the x direction is " << vx << " and in the y direction it is " << vy; 
    test();
    x += dt*vx;
    test();
    y += dt*vy;
    test();
}

void Animal::test()
{
    if(x > 1)
    {
        x = 1;
        vx *= (-1);
    }
    else if(x < 0)
    {
        x = 0;
        vx *= (-1);
    }
    if(y > 1)
    {
        y = 1;
        vy *= (-1);
    }
    else if(y < 0)
    {
        y = 0;
        vy *= (-1);
    }
}

float Animal::getX()
{
    
    return x;
}

float Animal::getY()
{
    return y;
}


/////////////////////////////////////////////////