#include "simulation.h"
#include "animal.h"
#include "tinygl-cpp.h"
#include "simplecanvas/simplecanvas.h"
#include "shapes.h"
#include <list>
#include <chrono> 
#include <thread> 
#include <iterator>
#include <math.h>
#include <stdio.h>
#include <vector>
using namespace std;
using std::vector;
using namespace tinygl;


/**
 * @brief This is a helper class to wrap around drawing functionality
 * DO NOT TOUCH THIS CLASS
 * 
 * This code is using the "pointer to implementation" design pattern 
 * to work in synchrony with the Simulation class
 * https://en.cppreference.com/w/cpp/language/pimpl
 */
class SimulationCanvas: public Window {
    private:
        int res;
        Simulation* simulation;
        float lastTime;
    public: 
        SimulationCanvas(Simulation* simulation, int res):Window(res, res) {
            this->simulation = simulation;
            this->res = res;
            lastTime = elapsedTime();
        }
        void circle(float x, float y, int r, int g, int b, float diameter) {
            color(r, g, b);
            ellipsoid((int)(res*x), (int)(res*y), res*diameter, res*diameter);
        }
        void square(float x, float y, float width, float height, int r, int g, int b)
        {
            color(r, g, b);
            Window::square((int)(res*x), (int)(res*y), (int)(res*width), (int)(res*height)); 
        }
        void triangle(float x, float y, float width, float height, int r, int g, int b)
        {
            color(r, g, b);
            Window::triangle((int)(res*x), (int)(res*y), (int)(res*width), (int)(res*height));
        }
        float timeElapsed()
        {
            return elapsedTime();
        }
        int getRes()
        {
            return res;
        }
        void draw() {
            background(0.8f, 0.8f, 0.8f);
            float time = elapsedTime();
            float dt = time - lastTime;
            lastTime = time; 
            simulation->step(dt);
        }
};

/**
 * @brief Construct a new simulation object
 * 
 * @param res The square resolution of the window
 */
Simulation::Simulation(int res, string shape, float height, float width, float vx, float vy, string fileName) {
    canvas = new SimulationCanvas(this, res);
    this->width = width;
    cout << "hello1\n";
    this->height = height;
    this->shape = shape;
    this->vx = vx;
    this->fileName = fileName; 
    this->vy = vy;
    this->runningStatus = true;
    int yellow[3] = {255, 255, 0};
    int black[3] = {0, 0, 0};
    for (int k = 0; k < 3; k++) {
        this->yellow[k] = yellow[k];
    }
    for (int k = 0; k < 3; k++) {
        this->black[k] = black[k];
    }
    if(shape == "triangle")
    {
        animals.push_back(new Animal(this, 0.5, 0.5+(height/2), vx, vy));
        animals.push_back(new Animal(this, 0.5-(width/2), 0.5-(height/2), vx, vy));
        animals.push_back(new Animal(this, 0.5+(width/2), 0.5-(height/2), vx, vy));
    }
    else if(shape == "square")
    {
        animals.push_back(new Animal(this, 0.5-(width/2), 0.5+(height/2), vx, vy));
        animals.push_back(new Animal(this, 0.5+(width/2), 0.5+(height/2), vx, vy));
        animals.push_back(new Animal(this, 0.5+(width/2), 0.5-(height/2), vx, vy));
        animals.push_back(new Animal(this, 0.5-(width/2), 0.5-(height/2), vx, vy));
    }
    this->res = (float)res;
    time = 0.0;
}

Simulation::Simulation(int res, string shape, float diameter, int numOfPoints, float vx, float vy, string fileName) {
    canvas = new SimulationCanvas(this, res);
    this->diameter = diameter;
    this->shape = shape;
    this->runningStatus = true;
    this->numOfPoints = numOfPoints; 
    this->fileName = fileName; 
    this->vx = vx;
    this->vy = vy;
    int yellow[3] = {255, 255, 0};
    int black[3] = {0, 0, 0};
    for (int k = 0; k < 3; k++) {
        this->yellow[k] = yellow[k];
    }
    for (int k = 0; k < 3; k++) {
        this->black[k] = black[k];
    } 
    if(shape == "circle")
    {
        for(int i = 1; i < numOfPoints+1; i++)
        {
            animals.push_back(new Animal(this, 0.5+(diameter/2)*cos((2*M_PI*i)/numOfPoints), 0.5+(diameter/2)*sin((2*M_PI*i)/numOfPoints), vx, vy));
        }
    } 
    this->res = (float)res;
    time = 0.0;   
}

/**
 * @brief Destroy the Simulation:: Simulation object
 * 
 */
Simulation::~Simulation() {
    // TODO: Cleanup dynamically allocated stuff here
    list<Animal*>::iterator it;
    for(it = animals.begin(); it != animals.end(); it++)
    {
        delete (*it);
        it = animals.erase(it);   
    }
    xvalues.clear();
    yvalues.clear();
    delete canvas; 
    
}

/**
 * @brief Wrapper around tinygl run method for continuous animation
 * 
 */
void Simulation::run() {
    canvas->run();
}

void Simulation::drawing()
{
    SimpleCanvas canvas(400, 400);
    canvas.clearRect(255, 255, 255);
    if(shape == "triangle")
    {
        drawTriangle(&canvas);
    }
    else if(shape == "square")
    {
        drawSquare(&canvas);
    }
    else if(shape == "circle")
    {
        drawCircle(&canvas);
    }
}

void Simulation::drawTriangle(SimpleCanvas* canvas)
{
    Point a(1, yellow, xvalues.at(1)*getRes(), 400-(yvalues.at(1)*getRes()));
    Point b(1, yellow, xvalues.at(0)*getRes(), 400-(yvalues.at(0)*getRes()));
    Point c(1, yellow, xvalues.at(2)*getRes(), 400-(yvalues.at(2)*getRes()));
    Triangle triangle(5, yellow, a, b, c);
    triangle.draw(canvas);
    drawPoints(canvas);
    canvas->write(fileName);
}

void Simulation::drawSquare(SimpleCanvas* canvas)
{
    Point a(5, yellow, xvalues.at(0)*getRes(), 400-(yvalues.at(0)*getRes()));
    Point b(5, yellow, xvalues.at(1)*getRes(), 400-(yvalues.at(1)*getRes()));
    Point c(5, yellow, xvalues.at(2)*getRes(), 400-(yvalues.at(2)*getRes()));
    Point d(5, yellow, xvalues.at(3)*getRes(), 400-(yvalues.at(3)*getRes()));
    Square square(5, yellow, a, b, c, d);
    square.draw(canvas);   
    drawPoints(canvas);
    canvas->write(fileName);
}

void Simulation::drawCircle(SimpleCanvas* canvas)
{
    Point center(5, yellow, 0.5*getRes(), 400-(0.5*getRes()));
    Circle circle(5, yellow, center, 16, (diameter/2)*getRes());
    circle.draw(canvas);
    drawPoints(canvas);
    canvas->write(fileName);
}

void Simulation::drawPoints(SimpleCanvas* canvas)
{
    if(xvalues.size() == yvalues.size())
  {
    for(int i = 0; i < xvalues.size(); i++)
    {
      Point one(2, black, xvalues.at(i)*getRes(), 400-(yvalues.at(i)*getRes()));
      one.draw(canvas);
    }
  }
}

int Simulation::getRes()
{
    return canvas->getRes();
}

/**
 * @brief Wrapper around tinygl circle method for drawing dots
 * 
 * @param x Location of dot in [0, 1]
 * @param y Location of dot in [0, 1]
 * @param r Red component in [0, 255]
 * @param g Green component in [0, 255]
 * @param b Blue component in [0, 255]
 * @param diameter Diameter of dot, in [0, 1]
 */
void Simulation::circle(float x, float y, int r, int g, int b, float diameter) {
    canvas->circle(x, y, r, g, b, diameter);
}

void Simulation::triangle(float x, float y, int r, int g, int b)
{
    canvas->triangle(x, y, width, height, r, g, b);
}

void Simulation::square(float x, float y, int r, int g, int b)
{
    canvas->square(x, y, width, height, r, g, b);
}

Animal* Simulation::findFriends(Animal* tu)
{
    list<Animal*>::iterator it = animals.begin();
    Animal* huh = NULL;
    bool found = false; 
    if(animals.size() > 1)
    {
        for(it = animals.begin(); it != animals.end(); it++){
            if((*it) == tu)
            {
                found = true;
            }
            else if((*it) != tu && found)
            {
                return (*it);
            }
        }
        if(found)
        {
            list<Animal*>::iterator it = animals.begin();
            return (*it); 
        }
    }
    return huh;
}

/**
 * @brief Do a step of the simulation.  Every animal should
 * move and take its action
 * 
 * @param dt The amount of time elaps0ed since the last step
 */
void Simulation::step(float dt) {
    // TODO: You should loop through the animals here
    // and take steps and draw them
    if(shape == "triangle")
    {
        triangle(0.5, 0.5, 255, 255, 0);
    }
    else if(shape == "square")
    {
        square(0.5, 0.5, 255, 255, 0);
    }
    else if(shape == "circle")
    {
        circle(0.5, 0.5, 255, 255, 0, diameter/2);
    }
    list<Animal*>::iterator it;
    list<Animal*>::iterator an; 
    int count = 0; 
    if(animals.size() > 1 && runningStatus == true)
    {
        for(it = animals.begin(); it != animals.end(); it++)
        {
            xvalues.push_back((*it)->getX());
            yvalues.push_back((*it)->getY());
            if(runningStatus == true)
            {
                (*it)->draw();
                (*it)->action(dt);
                for(an = animals.begin(); an != animals.end(); an++)
                {
                    if(abs((*it)->getX())-abs((*an)->getX()) < 0.0005 && abs((*it)->getY()) - abs((*an)->getY()) < 0.0005 && (*it) != (*an))
                    {
                        count++;
                    }
                    else if(abs((*it)->getX())-abs((*an)->getX()) > -0.0005 && abs((*it)->getY()) - abs((*an)->getY()) > -0.0005 && (*it) != (*an))
                    {
                        count++;
                    }
                    else 
                    {
                        cout << abs((*it)->getX())-abs((*an)->getX()) << "\n";
                    }
                    
                }
                if(count == animals.size()-1)
                {
                    this_thread::sleep_for(chrono::milliseconds(2000));
                    runningStatus = false;
                    cout << "The time elapsed is " << (canvas->timeElapsed()*1000) << " milliseconds.\n";
                    //drawing();
                }
                else if(count != animals.size())
                {
                    count = 0; 
                }
            }
            if(!runningStatus)
            {
                break;
            }
        }
    }
    else if(animals.size() > 1)
    {
        for(it = animals.begin(); it != animals.end(); it++)
        {
            (*it)->draw(); 
        }
    }
}