var searchData=
[
  ['drawline_1',['drawLine',['../classSimpleCanvas.html#a0d3fab74c4eb69d1ea6a9590afea97e1',1,'SimpleCanvas::drawLine(int x0, int y0, int x1, int y1, uint8_t R, uint8_t G, uint8_t B)'],['../classSimpleCanvas.html#a9948b85688e3f8b010e49e7a0defb677',1,'SimpleCanvas::drawLine(int x0, int y0, int x1, int y1, int thickness, uint8_t R, uint8_t G, uint8_t B)']]],
  ['drawrect_2',['drawRect',['../classSimpleCanvas.html#abc632cab60b786a10ff756b7db90e15e',1,'SimpleCanvas']]],
  ['drawstring_3',['drawString',['../classSimpleCanvas.html#a380f364b86b27ebaddebc720c2592792',1,'SimpleCanvas']]]
];
