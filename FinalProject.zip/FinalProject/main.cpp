#include "finalproject.h"
#include "shapes.h"
#include "simplecanvas/simplecanvas.h"
#include <iostream> 

int main()
{
    SimpleCanvas canvas(500, 500);
    canvas.clearRect(255, 255, 255);
    int thickness = 4;
    int yellow[3] = {255, 255, 0};
    Point a(thickness, yellow, 100, 325);
    Triangle triangle(thickness, yellow, a, 300);
    triangle.draw(&canvas);
    canvas.write("Final.png");
    return 0; 
}