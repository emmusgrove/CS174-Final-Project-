#include "simplecanvas/simplecanvas.h"
#include <string>
#include <sstream>
#include <math.h>
#include "shapes.h"
using namespace std;

Shape::Shape(float thickness, int color[3]) {
    this->thickness = thickness;
    for (int k = 0; k < 3; k++) {
        this->color[k] = color[k];
    }
}

void Shape::draw(SimpleCanvas* canvas) {
    cout << "Warning: Calling draw on base class";
}

/////////////////////////////////////////////////////

Point::Point(float thickness, int color[3], float ax, float ay):Shape(thickness, color) {
    this->ax = ax;
    this->ay = ay;
}

float Point::getX() {
    return ax;
}

float Point::getY() {
    return ay;
}

void Point::draw(SimpleCanvas* canvas) {
    canvas->fillCircle((int)ax, (int)ay, thickness, color[0], color[1], color[2]);
}

/////////////////////////////////////////////////////

LineSegment::LineSegment(float thickness, int color[3], 
                        Point a, Point b):Shape(thickness, color) {
    this->a = a;
    this->b = b;
}

float LineSegment::getLength() {
    float diffx = a.getX() - b.getX();
    float diffy = a.getY() - b.getY();
    return sqrt(diffx*diffx + diffy*diffy);
}

void LineSegment::draw(SimpleCanvas* canvas) {
    canvas->drawLine(a.getX(), a.getY(), b.getX(), b.getY(), thickness, color[0], color[1], color[2]);
}

/////////////////////////////////////////////////////

Triangle::Triangle(float thickness, int color[3], Point startingPoint, int length):Shape(thickness, color)
{
    int angle = 60;
    Point b(thickness, color, startingPoint.getX()+ cos(angle*(M_PI/180))*length, startingPoint.getY() - sin(angle*(M_PI/180))*length);
    Point c(thickness, color, startingPoint.getX()+length, startingPoint.getY());
    la = LineSegment(thickness, color, startingPoint, b);
    lb = LineSegment(thickness, color, b, c);
    lc = LineSegment(thickness, color, startingPoint, c);
    this->startingPoint = startingPoint;
    this->b = b;
    this->c = c;
}

void Triangle::draw(SimpleCanvas* canvas) {
    la.draw(canvas);
    lb.draw(canvas);
    lc.draw(canvas);
}

