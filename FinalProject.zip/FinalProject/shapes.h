#ifndef SHAPES_H
#define SHAPES_H

#include "simplecanvas/simplecanvas.h"
#include <iostream>
#include <string>
using namespace std;

class Shape {
    protected:
        float thickness;
        int color[3];
    public:
        Shape(float thickness, int color[3]);
        Shape(){};
        void draw(SimpleCanvas* canvas);
};

class Point: public Shape {
    private:
        float ax;
        float ay;
    public:
        Point(float thickness, int color[3], float ax, float ay);
        Point(){};
        float getX();
        float getY();
        void draw(SimpleCanvas* canvas);
};



class LineSegment: public Shape {
    private:
        Point a;
        Point b;
    public:
        LineSegment(float thickness, int color[3], Point a, Point b);
        LineSegment(){};
        float getLength();
        void draw(SimpleCanvas* canvas);
};

class Triangle: public Shape {
    private:
        LineSegment la;
        LineSegment lb;
        LineSegment lc;
        Point startingPoint; 
        Point b;
        Point c;
    public:
        Triangle(float thickness, int color[3], Point startingPoint, int length);
        Triangle(){};
        void draw(SimpleCanvas* canvas);
};

#endif